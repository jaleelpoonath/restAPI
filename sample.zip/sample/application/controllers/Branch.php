<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Branch extends CI_Controller
{

    function __construct() {
        parent::__construct();   
        $this->load->database(); 
        //$this->load->library('tank_auth');
        //$this->lang->load('tank_auth');
        $this->load->library('rest', array('server' => WEB_URL,
                        'api_key'         => '550e840022',
                        'api_name'        => 'X-API-KEY',
                        'http_user'       => 'admin',
                        'http_pass'       => '1234',
                        'http_auth'       => 'basic',
                       )); 
             
    }




    /*=============LIST ALL ACTIVE BRANCHES==============*/
    public function index() {
        $data['result'] = $this->rest->get('API_Branch/view_branch/status/1/');
        $this->rest->debug();
    }


   /*=============INSERT NEW BRANCH===============*/
    public function save_branch() {

        $this->rest->format('application/json');   

        $data = array(
            'branch_name'           => $this->input->post('name'),
            'branch_place'          => $this->input->post('place'),
            'branch_status'         => $this->input->post('status'),
        );

        $j_data = json_encode($data);
        
        $rslt = $this->rest->post('API_Branch/save_branch/',$j_data);
        
        redirect('branch/view_branch');
    }

    ###############################################
 
}

?>