<?php
defined('BASEPATH') OR exit('No direct script access allowed');



class Branch_model extends CI_Model{



    public function insert($table,$data) {

        $this->db->insert($table, $data);

        return TRUE;
    }

    public function select_all($table, $condition = null) {
        $this->db->select('*');
        
        $this->db->from($table);
        
        if($condition)
            $this->db->where($condition)
        
        $query = $this->db->get();
        
        $data = $query->result_array();
        
        return $data;
    }

 









 

}